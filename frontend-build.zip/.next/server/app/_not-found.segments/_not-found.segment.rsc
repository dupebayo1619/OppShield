1:"$Sreact.fragment"
2:I[32035,["/_next/static/chunks/443ujwfk5c32x.js","/_next/static/chunks/21p-i82-2u343.js"],"default"]
3:I[91168,["/_next/static/chunks/443ujwfk5c32x.js","/_next/static/chunks/21p-i82-2u343.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"jb0G3so1_WQLYAl8JNgeF"}
