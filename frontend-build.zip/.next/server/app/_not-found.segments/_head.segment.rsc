1:"$Sreact.fragment"
2:I[64381,["/_next/static/chunks/443ujwfk5c32x.js","/_next/static/chunks/21p-i82-2u343.js"],"ViewportBoundary"]
3:I[64381,["/_next/static/chunks/443ujwfk5c32x.js","/_next/static/chunks/21p-i82-2u343.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[12843,["/_next/static/chunks/443ujwfk5c32x.js","/_next/static/chunks/21p-i82-2u343.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"OpsShield"}],["$","meta","1",{"name":"description","content":"Internal operations platform"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jb0G3so1_WQLYAl8JNgeF"}
