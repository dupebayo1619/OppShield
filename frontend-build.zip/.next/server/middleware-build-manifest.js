globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/jb0G3so1_WQLYAl8JNgeF/_buildManifest.js",
    "static/jb0G3so1_WQLYAl8JNgeF/_ssgManifest.js",
    "static/jb0G3so1_WQLYAl8JNgeF/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/13htka2--ic-5.js",
    "static/chunks/239j6i8_ui0sr.js",
    "static/chunks/2w8jvw8h8onvj.js",
    "static/chunks/2bqp86do_72z7.js",
    "static/chunks/turbopack-3fgzfwytkk13j.js"
  ]
};
